﻿Imports System.Data
Imports System.Data.OleDb


Public Class Formpenerjemah
    Inherits System.Web.UI.Page
    Dim Koneksi As String = "provider=Microsoft.ACE.OLEDB.12.0;data source=C:\Users\TATA\Documents\UTS.accdb"
    Dim objekKoneksi As New OleDb.OleDbConnection(Koneksi)
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    End Sub

    Protected Sub ImageButton1_Click(sender As Object, e As ImageClickEventArgs) Handles ImageButton1.Click
        Response.Redirect("Home.aspx")
    End Sub

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        objekKoneksi.Open()
        Dim tambah As String = "INSERT INTO tbl_penerjemah values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "') "
        Dim oCmd = New OleDbCommand(tambah, objekKoneksi)
        oCmd.ExecuteNonQuery()
        objekKoneksi.Close()
        MsgBox("Terima kasih, Data Sudah tersimpan")
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b As Single

        a = TextBox6.Text
        b = a * 2500000
        TextBox7.Text = b
    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        MsgBox("Data terhapus! Silahkan masukan data baru.")
    End Sub
End Class