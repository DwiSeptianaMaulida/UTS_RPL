﻿Imports System.Data
Imports System.Data.OleDb

Public Class Formalat
    Inherits System.Web.UI.Page
    Dim Koneksi As String = "provider=Microsoft.ACE.OLEDB.12.0;data source=C:\Users\TATA\Documents\UTS.accdb"
    Dim objekKoneksi As New OleDb.OleDbConnection(Koneksi)

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox4.Text = "" Then
        Else
            TextBox6.Text = ""
            MsgBox("Mohon isi semua data!")
        End If
        Dim a, b, c As Single
        a = TextBox4.Text
        b = TextBox6.Text
        c = a * b * 100000
        TextBox7.Text = c

    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        MsgBox("Data terhapus! Silahkan masukan data baru.")

    End Sub

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        objekKoneksi.Open()
        Dim tambah As String = "INSERT INTO tbl_alat values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "') "
        Dim oCmd = New OleDbCommand(tambah, objekKoneksi)
        oCmd.ExecuteNonQuery()
        objekKoneksi.Close()
        MsgBox("Terima kasih, Data Sudah tersimpan")
    End Sub

    Protected Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Protected Sub ImageButton1_Click(sender As Object, e As ImageClickEventArgs) Handles ImageButton1.Click
        Response.Redirect("Home.aspx")
    End Sub
End Class