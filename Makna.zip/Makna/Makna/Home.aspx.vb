﻿Public Class Home
        Inherits System.Web.UI.Page

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        End Sub

        Protected Sub LinkButton1_Click(sender As Object, e As EventArgs) Handles LinkButton1.Click
            Response.Redirect("Formalat.aspx")
        End Sub

        Protected Sub LinkButton2_Click(sender As Object, e As EventArgs) Handles LinkButton2.Click
            Response.Redirect("Gridview.aspx")
        End Sub

    Protected Sub LinkButton3_Click(sender As Object, e As EventArgs) Handles LinkButton3.Click
        Response.Redirect("Formpenerjemah.aspx")
    End Sub

    Protected Sub LinkButton4_Click(sender As Object, e As EventArgs) Handles LinkButton4.Click
        Response.Redirect("Data_transaksi.aspx")
    End Sub
End Class